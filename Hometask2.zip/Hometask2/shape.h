#ifndef HOMETASK2_SHAPE_H
#define HOMETASK2_SHAPE_H

#include <fstream>
#include "rnd.h"

// Структура, обобщающая все имеющиеся фигуры
class shape {
protected:
    // Плотность
    double density;

public:
    // Конструктор класса shape
    explicit shape(double density);

    // Ввод обобщенной фигуры
    static shape *In(std::ifstream &ifst);

    // Случайный ввод обобщенной фигуры
    static shape *InRnd();

    // Вывод обобщенной фигуры
    virtual void Out(std::ofstream &ofst);

    // Вычисление периметра обобщенной фигуры
    virtual double Volume();
};

#endif //HOMETASK2_SHAPE_H
