#ifndef HOMETASK2_PARALLELEPIPED_H
#define HOMETASK2_PARALLELEPIPED_H

#include <fstream>
#include "shape.h"
#include "rnd.h"

// Параллелепипед
class Parallelepiped : public shape {
    // Длина, ширина, высота
    int x, y, z;

    // Плотность
    int density;

public:

    // Конструктор класса Parallelepiped
    Parallelepiped(int x, int y, int z, double density);

    // Вывод параметров параллелепипеда в форматируемый поток
    void Out(std::ofstream &ofst) override;

    // Вычисление объема параллелепипеда
    double Volume() override;
};

#endif //HOMETASK2_PARALLELEPIPED_H
