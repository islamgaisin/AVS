#include <fstream>
#include "container.h"

// Конструктор класа container
container::container() {
    this->len = 0;
}

// Очистка контейнера от элементов (освобождение памяти)
void container::Clear() {
    for(int i = 0; i < this->len; i++) {
        delete this->cont[i];
    }
    this->len = 0;
}

// Ввод содержимого контейнера из указанного потока
void container::In(std::ifstream &ifst) {
    while(!ifst.eof()) {
        if((this->cont[this->len] = shape::In(ifst)) != nullptr) {
            this->len++;
        }
    }
}

// Случайный ввод содержимого контейнера
void container::InRnd(int size) {
    while(this->len < size) {
        if((this->cont[this->len] = shape::InRnd()) != nullptr) {
            this->len++;
        }
    }
}

// Вывод содержимого контейнера в указанный поток
void container::Out(std::ofstream &ofst) {
    ofst << "Container contains " << this->len << " elements." << "\n";
    for(int i = 0; i < this->len; i++) {
        ofst << i + 1 << ": ";
        this->cont[i]->Out(ofst);
    }
}

// Сортировка элементов в контейнере
void container::SortWithBinaryInsertion()
{
    shape *key;
    int left, right, middle;
    for (int i = 0; i < this->len; ++i) {
        key = this->cont[i];
        left = 0;
        right = i;
        while (left < right) {
            middle = left + (right - left) / 2;
            if (key->Volume() < this->cont[middle]->Volume()) {
                right = middle;
            } else {
                left = middle + 1;
            }
        }
        for (int j = i; j >= left + 1; --j) {
            this->cont[j] = this->cont[j - 1];
        }
        this->cont[left] = key;
    }
}
