#include "shape.h"
#include "Ball.h"
#include "Parallelepiped.h"
#include "Tetrahedron.h"
#include "rnd.h"

// Конструктор класса shape
shape::shape(double density) {
    this->density = density;
}

// Ввод параметров обобщенной фигуры из файла
shape *shape::In(std::ifstream &ifst) {
    double density;
    int k;
    ifst >> k;
    switch(k) {
        case 1:
            int radius;
            ifst >> radius >> density;
            return new Ball(radius, density);
        case 2:
            int x, y, z;
            ifst >> x >> y >> z >> density;
            return new Parallelepiped(x, y, z, radius);
        case 3:
            int a;
            ifst >> a >> density;
            return new Tetrahedron(a, density);
        default:
            return nullptr;
    }
}

// Случайный ввод обобщенной фигуры
shape *shape::InRnd() {
    shape *sh;
    int radius, x, y, z, a;
    auto k = random() % 3 + 1;
    double density = random() % 25000 + 1;
    switch(k) {
        case 1:
            radius = Random();
            return new Ball(radius, density);
        case 2:
            x = Random();
            y = Random();
            z = Random();
            return new Parallelepiped(x, y, z, density);
        case 3:
            a = Random();
            return new Tetrahedron(a, density);
        default:
            return nullptr;
    }
}

// Вывод параметров текущей фигуры в поток
void shape::Out(std::ofstream &ofst){}

// Вычисление объема фигуры
double shape::Volume(){
    return 0;
}
