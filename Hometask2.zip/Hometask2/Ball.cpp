#include "Ball.h"

// Конструктор класса Ball
Ball::Ball(int radius, double density) : shape(density){
    this->radius = radius;
}

// Вывод параметров шара в поток
void Ball::Out(std::ofstream &ofst) {
    ofst << "It is Ball: radius = " << this->radius
         << ". Density = " << this->density
         << ". Volume = " << this->Volume() << "\n";
}

// Вычисление объема шара
double Ball::Volume() {
    return 4.0 / 3 * 3.141592 * this->radius * this->radius * this->radius;
}
