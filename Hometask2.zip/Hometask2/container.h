#ifndef HOMETASK2_CONTAINER_H
#define HOMETASK2_CONTAINER_H

#include <fstream>
#include "shape.h"

// Простейший контейнер на основе одномерного массива
class container {
private:
    static int const max_len = 10000;// максимальная длина
    int len; // текущая длина
    shape *cont[max_len];

public:

    // Конструктор класа container
    container();

    // Очистка контейнера от элементов (освобождение памяти)
    void Clear();

    // Ввод содержимого контейнера из указанного потока
    void In(std::ifstream &ifst);

    // Случайный ввод содержимого контейнера
    void InRnd(int size);

    // Вывод содержимого контейнера в указанный поток
    void Out(std::ofstream &ofst);

    // Сортировка элементов в контейнере
    void SortWithBinaryInsertion();
};

#endif //HOMETASK2_CONTAINER_H
