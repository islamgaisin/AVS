#include "Parallelepiped.h"


// Конструктор класса Parallelepiped
Parallelepiped::Parallelepiped(int x, int y, int z, double density) : shape(density){
    this->x = x;
    this->y = y;
    this->z = z;
}

// Вывод параметров параллелепипеда в форматируемый поток
void Parallelepiped::Out(std::ofstream &ofst) {
    ofst << "It is Parallelepiped: x = " << this->x << ", y = " << this->y
         << ", z = " << this->z <<
         ". Density = " << this->density <<
         ". Volume = " << this->Volume() << "\n";
}

// Вычисление периметра параллелепипеда
double Parallelepiped::Volume() {
    return this->x * this->y * this->z;
}
