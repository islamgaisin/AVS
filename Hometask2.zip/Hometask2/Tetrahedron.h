#ifndef HOMETASK2_TETRAHEDRON_H
#define HOMETASK2_TETRAHEDRON_H

#include <fstream>
#include "shape.h"
#include "rnd.h"

// Тетраэдр
class Tetrahedron : public shape {

    // Длина ребра
    int a;

    // Плотность
    int density;

public:
    // Конструктор класса Tetrahedron
    Tetrahedron(int a, double density);

    // Вывод параметров тетраэдра в форматируемый поток
    virtual void Out(std::ofstream &ofst) override;

    // Вычисление периметра тетраэдра
    virtual double Volume() override;
};

#endif //HOMETASK2_TETRAHEDRON_H
