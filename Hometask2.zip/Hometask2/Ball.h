#ifndef HOMETASK2_BALL_H
#define HOMETASK2_BALL_H

#include <fstream>
#include "shape.h"
#include "rnd.h"

// Шар
class Ball : public shape {
private:
    // Радиус
    int radius;

public:
    // Конструктор класса Ball
    Ball(int radius, double density);

    // Вывод параметров шара в форматируемый поток
    void Out(std::ofstream &ofst) override;

    // Вычисление объема шара
    double Volume() override;
};

#endif //HOMETASK2_BALL_H
