#include <cmath>
#include "Tetrahedron.h"

// Конструктор класса Tetrahedron
Tetrahedron::Tetrahedron(int a, double density) : shape(density){
    this->a = a;
}

// Вывод параметров тетраэдра в поток
void Tetrahedron::Out(std::ofstream &ofst) {
    ofst << "It is Tetrahedron: a = " << this->a <<
         ". Density = " << this->density <<
         ". Volume = " << this->Volume() << "\n";
}

// Вычисление объема тетраэдра
double Tetrahedron::Volume() {
    return this->a * this->a * this->a * sqrt(2) / 12;
}
