//------------------------------------------------------------------------------
// inrnd.c - единица компиляции, вбирающая функции генерации случайных данных
//------------------------------------------------------------------------------

#include <stdlib.h>

#include "extdataVol.h"

// rnd.c - содержит генератор случайных чисел в диапазоне от 1 до 20
int Random() {
    return rand() % 20 + 1;
}

// Случайный ввод параметров шара
void InRndBall(void *b) {
    int radius = Random();
    *((int*)b) = radius;
    int density = Random();
    *((int*)(b+intSize)) = density;
//     printf("    Ball %d %d\n", *((int*)b), *((int*)b+1));
}

// Случайный ввод параметров параллелепипеда
void InRndParallelepiped(void *p) {
    int a, b, c, density;
    a = *((int*)p) = Random();
    b = *((int*)(p+intSize)) = Random();
    c = *((int*)(p+2*intSize)) = Random();
    density = *((int*)(p+3*intSize)) = Random();
//     printf("    Parallelepiped %d %d %d %d\n", *((int*)p), *((int*)p+1),
//		*((int*)p+2), *((int*)p+3);
}

// Случайный ввод параметров тетраэдра
void InRndTetrahedron(void *t) {
    int a = Random();
    *((int*)t) = a;
    int density = Random();
    *((int*)(t+intSize)) = density;
//     printf("    Tetrahedron %d %d\n", *((int*)t), *((int*)t+1));
}

// Случайный ввод обобщенной фигуры
int InRndShape(void *s) {
    int k = rand() % 3 + 1;
    switch(k) {
        case 1:
            *((int*)s) = BALL;
            InRndBall(s+intSize);
//              printf("Shape %d %d %d %d\n",
//                     *((int*)s), *((int*)s+1),
//                     *((int*)s+2), *((int*)s+3));
            return 1;
        case 2:
            *((int*)s) = PARALLELEPIPED;
            InRndParallelepiped(s+intSize);
//              printf("Shape %d %d %d %d\n",
//                     *((int*)s), *((int*)s+1),
//                     *((int*)s+2), *((int*)s+3));
            return 1;
        case 3:
            *((int*)s) = TETRAHEDRON;
            InRndTetrahedron(s+intSize);
//              printf("Shape %d %d %d %d\n",
//                     *((int*)s), *((int*)s+1),
//                     *((int*)s+2), *((int*)s+3));
            return 1;
        default:
            return 0;
    }
}

// Случайный ввод содержимого контейнера
void InRndContainer(void *c, int *len, int size) {
    void *tmp = c;
    while(*len < size) {
        if(InRndShape(tmp)) {
            tmp = tmp + shapeSize;
            (*len)++;
        }
    }
}
