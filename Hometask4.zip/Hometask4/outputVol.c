//------------------------------------------------------------------------------
// output.c - единица компиляции, вбирающая в себя все функции вывода данных
//------------------------------------------------------------------------------

#include <stdio.h>

#include "extdataVol.h"

// Вычисление периметра шара
double BallVolume(void *b);
// Вывод параметров шара в файл
void OutBall(void *b, FILE *ofst) {
    fprintf(ofst, "It is Ball: radius = %d, density = %d. Volume = %g\n",
            *((int*)b), *((int*)(b+intSize)), BallVolume(b));
}

// Вычисление периметра параллелепипеда
double ParallelepipedVolume(void *p);
// Вывод параметров параллелепипеда в файл
void OutParallelepiped(void *p, FILE *ofst) {
    fprintf(ofst, "It is Parallelepiped: a = %d, b = %d, c = %d, density = %d. Volume = %g\n",
           *((int*)p), *((int*)(p+intSize)), *((int*)(p+2*intSize)), *((int*)(p+3*intSize)),
            ParallelepipedVolume(p));
}

// Вычисление периметра тетраэдра
double TetrahedronVolume(void *t);
// Вывод параметров тетраэдра в файл
void OutTetrahedron(void *t, FILE *ofst) {
    fprintf(ofst, "It is Tetrahedron: a = %d, density = %d. Volume = %g\n",
            *((int*)t), *((int*)(t+intSize)), TetrahedronVolume(t));
}

// Вывод параметров текущей фигуры в поток
void OutShape(void *s, FILE *ofst) {
    int k = *((int*)s);
    if (k == BALL) {
        OutBall(s+intSize, ofst);
    } else if (k == PARALLELEPIPED) {
        OutParallelepiped(s+intSize, ofst);
    } else if (k == TETRAHEDRON) {
        OutTetrahedron(s+intSize, ofst);
    }
    else {
        fprintf(ofst, "Incorrect figure!\n");
    }
}

// Вывод содержимого контейнера в файл
void OutContainer(void *c, int len, FILE *ofst) {
    void *tmp = c;
    fprintf(ofst, "Container contains %d elements.\n", len);
    for(int i = 0; i < len; i++) {
        fprintf(ofst, "%d: ", i+1);
        OutShape(tmp, ofst);
        tmp = tmp + shapeSize;
    }
}
