//------------------------------------------------------------------------------
// input.c - единица компиляции, вбирающая в себя все функции ввода данных
//------------------------------------------------------------------------------

#include <stdio.h>

#include "extdataVol.h"

// Ввод параметров шара из файла
void InBall(void *b, FILE *ifst) {
    fscanf(ifst, "%d%d", (int*)b, (int*)(b+intSize));
    //printf("    Ball %d %d\n", *((int*)b), *((int*)b+1));
}

// Ввод параметров параллелепипеда из файла
void InParallelepiped(void *p, FILE *ifst) {
    fscanf(ifst, "%d%d%d%d", (int*)p, (int*)(p+intSize),
    		(int*)(p+2*intSize), (int*)(p+3*intSize));
    //printf("    Parallelepiped %d %d %d %d\n", *((int*)p), *((int*)p+1),
    //		*((int*)p+2), *((int*)p+3);
}

// Ввод параметров тетраэдра из файла
void InTetrahedron(void *t, FILE *ifst) {
    fscanf(ifst, "%d%d", (int*)t, (int*)(t+intSize));
    //printf("    Tetrahedron %d %d\n", *((int*)t), *((int*)t+1));
}

// Ввод параметров обобщенной фигуры из файла
int InShape(void *s, FILE *ifst) {
    int k;
    fscanf(ifst, "%d", &k);
    switch(k) {
        case 1:
            *((int*)s) = BALL;
            InBall(s+intSize, ifst);
            return 1;
        case 2:
            *((int*)s) = PARALLELEPIPED;
            InParallelepiped(s+intSize, ifst);
            return 1;
        case 3:
            *((int*)s) = TETRAHEDRON;
            InTetrahedron(s+intSize, ifst);
            return 1;
        default:
            return 0;
    }
}

// Ввод содержимого контейнера из указанного файла
void InContainer(void *c, int *len, FILE *ifst) {
    void *tmp = c;
    while(!feof(ifst)) {
        if(InShape(tmp, ifst)) {
            tmp = tmp + shapeSize;
            (*len)++;
        }
    }
}
