#include <fstream>
#include "container.h"

// Инициализация контейнера
void Init(container &c) {
    c.len = 0;
}

// Очистка контейнера от элементов (освобождение памяти)
void Clear(container &c) {
    for(int i = 0; i < c.len; i++) {
        DeleteShape(c.cont[i]);
    }
    c.len = 0;
}

// Ввод содержимого контейнера из указанного потока
void In(container &c, std::ifstream &ifst) {
    while(!ifst.eof()) {
        if((c.cont[c.len] = In(ifst)) != 0) {
            c.len++;
        }
    }
}

// Случайный ввод содержимого контейнера
void InRnd(container &c, int size) {
    while(c.len < size) {
        if((c.cont[c.len] = InRnd()) != nullptr) {
            c.len++;
        }
    }
}

//------------------------------------------------------------------------------
// Вывод содержимого контейнера в указанный поток
void Out(container &container, std::ofstream &ofst) {
    ofst << "Container contains " << container.len << " elements." << "\n";
    for(int i = 0; i < container.len; i++) {
        ofst << i + 1 << ": ";
        Out(*(container.cont[i]), ofst);
    }
}

// Вспомогательная функция для сортировки
int binarySearch(shape *array, shape &item, int low, int high) {
    double volumeItem;
    switch(item.k) {
        case shape::BALL:
            volumeItem = Volume(item);
            break;
        case shape::PARALLELEPIPED:
            volumeItem = Volume(item);
            break;
        case shape::TETRAHEDRON:
            volumeItem = Volume(item);
            break;
        default:
            volumeItem = 0;
            break;
    }

    double volumeLow;
    switch(array[low].k) {
        case shape::BALL:
            volumeLow = Volume(array[low]);
            break;
        case shape::PARALLELEPIPED:
            volumeLow = Volume(array[low]);
            break;
        case shape::TETRAHEDRON:
            volumeLow = Volume(array[low]);
            break;
        default:
            volumeLow = 0;
            break;
    }

    if (high <= low) {
        return (volumeItem > volumeLow) ? (low + 1) : low;
    }

    int mid = (low + high) / 2;
    double volumeMid;
    switch(array[mid].k) {
        case shape::BALL:
            volumeMid = Volume(array[mid]);
            break;
        case shape::PARALLELEPIPED:
            volumeMid = Volume(array[mid]);
            break;
        case shape::TETRAHEDRON:
            volumeMid = Volume(array[mid]);
            break;
        default:
            volumeMid = 0;
            break;
    }
    if (volumeItem == volumeMid) {
        return mid + 1;
    }
    if (volumeItem > volumeMid) {
        return binarySearch(array, item, mid + 1, high);
    }
    return binarySearch(array, item, low, mid - 1);
}

// Сортировка элементов в контейнере
void SortWithBinaryInsertion(container &container)
{
    int i, loc, j, k;
    shape selected;

    for (i = 1; i < sizeof(container.cont); ++i)
    {
        j = i - 1;
        selected = *container.cont[i];

        // Место, куда надо вставить элемент
        loc = binarySearch(*container.cont, selected, 0, j);

        // Передвинуть элементы
        while (j >= loc)
        {
            container.cont[j + 1] = container.cont[j];
            j--;
        }
        container.cont[j + 1] = &selected;
    }
}
