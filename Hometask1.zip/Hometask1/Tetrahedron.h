#ifndef HOMETASK1_TETRAHEDRON_H
#define HOMETASK1_TETRAHEDRON_H

#include <fstream>
#include "rnd.h"

// Тетраэдр
struct Tetrahedron {
    int a; // Длина ребра
    int density; // Плотность
};

// Ввод параметров тетраэдра из файла
void In(Tetrahedron &tetrahedron, std::ifstream &ifst);

// Случайный ввод параметров тетраэдра
void InRnd(Tetrahedron &tetrahedron);

// Вывод параметров тетраэдра в форматируемый поток
void Out(Tetrahedron &tetrahedron, std::ofstream &ofst);

// Вычисление периметра тетраэдра
double Volume(Tetrahedron &tetrahedron);

#endif //HOMETASK1_TETRAHEDRON_H
