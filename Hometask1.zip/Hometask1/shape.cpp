#include "shape.h"

// Ввод параметров обобщенной фигуры из файла
shape* In(std::ifstream &ifst) {
    shape *sh;
    int k;
    ifst >> k;
    switch(k) {
        case 1:
            sh = new shape;
            sh->k = shape::BALL;
            In(sh->ball, ifst);
            return sh;
        case 2:
            sh = new shape;
            sh->k = shape::PARALLELEPIPED;
            In(sh->parallelepiped, ifst);
            return sh;
        case 3:
            sh = new shape;
            sh->k = shape::TETRAHEDRON;
            In(sh->tetrahedron, ifst);
            return sh;
        default:
            return 0;
    }
}

// Случайный ввод обобщенной фигуры
shape *InRnd() {
    shape *sh;
    auto k = random() % 3 + 1;
    switch(k) {
        case 1:
            sh = new shape;
            sh->k = shape::BALL;
            InRnd(sh->ball);
            return sh;
        case 2:
            sh = new shape;
            sh->k = shape::PARALLELEPIPED;
            InRnd(sh->parallelepiped);
            return sh;
        case 3:
            sh = new shape;
            sh->k = shape::TETRAHEDRON;
            InRnd(sh->tetrahedron);
            return sh;
        default:
            return 0;
    }
}

// Вывод параметров текущей фигуры в поток
void Out(shape &s, std::ofstream &ofst) {
    switch(s.k) {
        case shape::BALL:
            Out(s.ball, ofst);
            break;
        case shape::PARALLELEPIPED:
            Out(s.parallelepiped, ofst);
            break;
        case shape::TETRAHEDRON:
            Out(s.tetrahedron, ofst);
            break;
        default:
            ofst << "Incorrect figure!" << "\n";
    }
}

// Вычисление объема фигуры
double Volume(shape &s) {
    switch(s.k) {
        case shape::BALL:
            return Volume(s.ball);
        case shape::PARALLELEPIPED:
            return Volume(s.parallelepiped);
        case shape::TETRAHEDRON:
            return Volume(s.tetrahedron);
        default:
            return 0.0;
    }
}

// Удаление обобщенной фигуры
void DeleteShape(shape *s) {
    switch(s->k) {
        case shape::BALL:
            delete (Ball*)s;
            break;
        case shape::PARALLELEPIPED:
            delete (Parallelepiped*)s;
            break;
        case shape::TETRAHEDRON:
            delete (Tetrahedron*)s;
            break;
        default:
            break;
    }
}
