#ifndef HOMETASK1_CONTAINER_H
#define HOMETASK1_CONTAINER_H

#include <fstream>
#include "shape.h"
//------------------------------------------------------------------------------
// Простейший контейнер на основе одномерного массива
struct container {
    enum {max_len = 10000}; // максимальная длина
    int len; // текущая длина
    shape *cont[max_len];
};

// Инициализация контейнера
void Init(container &c);

// Очистка контейнера от элементов (освобождение памяти)
void Clear(container &c);

// Ввод содержимого контейнера из указанного потока
void In(container &c, std::ifstream &ifst);

// Случайный ввод содержимого контейнера
void InRnd(container &c, int size);

// Вывод содержимого контейнера в указанный поток
void Out(container &c, std::ofstream &ofst);

// Сортировка элементов в контейнере
void SortWithBinaryInsertion(container &c);

#endif //HOMETASK1_CONTAINER_H
