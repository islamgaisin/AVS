#include "Parallelepiped.h"

// Ввод параметров прямоугольника из файла
void In(Parallelepiped &parallelepiped, std::ifstream &ifst) {
    ifst >> parallelepiped.x >> parallelepiped.y >> parallelepiped.z >> parallelepiped.density;
}

// Случайный ввод параметров прямоугольника
void InRnd(Parallelepiped &parallelepiped) {
    parallelepiped.x = Random();
    parallelepiped.y = Random();
    parallelepiped.z = Random();
    parallelepiped.density = Random();
}

// Вывод параметров прямоугольника в форматируемый поток
void Out(Parallelepiped &parallelepiped, std::ofstream &ofst) {
    ofst << "It is Parallelepiped: x = " << parallelepiped.x << ", y = " << parallelepiped.y
         << ", z = " << parallelepiped.z <<
         ". Density = " << parallelepiped.density <<
         ". Volume = " << Volume(parallelepiped) << "\n";
}

//------------------------------------------------------------------------------
// Вычисление периметра прямоугольника
double Volume(Parallelepiped &parallelepiped) {
    return parallelepiped.x * parallelepiped.y * parallelepiped.z;
}
