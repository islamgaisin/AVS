#ifndef HOMETASK1_PARALLELEPIPED_H
#define HOMETASK1_PARALLELEPIPED_H

#include <fstream>
#include "rnd.h"

// прямоугольник
struct Parallelepiped {
    int x, y, z; // Длина, ширина, высота
    int density; // Плотность
};

// Ввод параметров параллелепипеда из файла
void In(Parallelepiped &parallelepiped, std::ifstream &ifst);

// Случайный ввод параметров параллелепипеда
void InRnd(Parallelepiped &parallelepiped);

// Вывод параметров параллелепипеда в форматируемый поток
void Out(Parallelepiped &parallelepiped, std::ofstream &ofst);

// Вычисление объема параллелепипеда
double Volume(Parallelepiped &parallelepiped);

#endif //HOMETASK1_PARALLELEPIPED_H
