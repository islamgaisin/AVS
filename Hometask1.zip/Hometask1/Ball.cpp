#include "Ball.h"

// Ввод параметров шара из потока
void In(Ball &ball, std::ifstream &ifst) {
    ifst >> ball.radius >> ball.density;
}

// Случайный ввод параметров шара
void InRnd(Ball &ball) {
    ball.radius = Random();
    ball.density = Random();
}

//------------------------------------------------------------------------------
// Вывод параметров шара в поток
void Out(Ball &ball, std::ofstream &ofst) {
    ofst << "It is Ball: radius = " << ball.radius
         << ". Density = " << ball.density
         << ". Volume = " << Volume(ball) << "\n";
}

// Вычисление объема шара
double Volume(Ball &ball) {
    return 4.0 / 3 * 3.141592 * ball.radius * ball.radius * ball.radius;
}
