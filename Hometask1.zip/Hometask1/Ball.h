#ifndef HOMETASK1_BALL_H
#define HOMETASK1_BALL_H

#include <fstream>
#include "rnd.h"

//------------------------------------------------------------------------------
// треугольник
struct Ball {
    long radius; // Радиус
    long density; // Плотность
};

// Ввод параметров шара из файла
void In(Ball &ball, std::ifstream &ifst);

// Случайный ввод параметров шара
void InRnd(Ball &ball);

// Вывод параметров шара в форматируемый поток
void Out(Ball &ball, std::ofstream &ofst);

// Вычисление объема шара
double Volume(Ball &ball);

#endif //HOMETASK1_BALL_H
