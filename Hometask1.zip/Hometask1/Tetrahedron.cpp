#include <math.h>
#include "Tetrahedron.h"

// Ввод параметров тетраэдра из потока
void In(Tetrahedron &tetrahedron, std::ifstream &ifst) {
    ifst >> tetrahedron.a >> tetrahedron.density;
}

// Случайный ввод параметров тетраэдра
void InRnd(Tetrahedron &tetrahedron) {
    tetrahedron.a = Random();
    tetrahedron.density = Random();
}

// Вывод параметров тетраэдра в поток
void Out(Tetrahedron &tetrahedron, std::ofstream &ofst) {
    ofst << "It is Tetrahedron: a = " << tetrahedron.a <<
    ". Density = " << tetrahedron.density <<
    ". Volume = " << Volume(tetrahedron) << "\n";
}

// Вычисление объема тетраэдра
double Volume(Tetrahedron &tetrahedron) {
    return tetrahedron.a * tetrahedron.a * tetrahedron.a * sqrt(2) / 12;
}
