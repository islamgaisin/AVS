#ifndef HOMETASK1_SHAPE_H
#define HOMETASK1_SHAPE_H

#include <fstream>
#include "Ball.h"
#include "Parallelepiped.h"
#include "Tetrahedron.h"

// структура, обобщающая все имеющиеся фигуры
struct shape {
    // значения ключей для каждой из фигур
    enum key {BALL, PARALLELEPIPED, TETRAHEDRON};
    key k; // ключ
    // используемые альтернативы
    union { // используем простейшую реализацию
        Ball ball;
        Parallelepiped parallelepiped;
        Tetrahedron tetrahedron;
    };
};

// Ввод обобщенной фигуры
shape *In(std::ifstream &ifst);

// Случайный ввод обобщенной фигуры
shape *InRnd();

// Вывод обобщенной фигуры
void Out(shape &s, std::ofstream &ofst);

// Вычисление периметра обобщенной фигуры
double Volume(shape &s);

// Удаление обобщенной фигуры
void DeleteShape(shape *s);

#endif //HOMETASK1_SHAPE_H
