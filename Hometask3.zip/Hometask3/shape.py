# Базовый класс Фигура
class Shape:
    # Конструктор, утанавливаем плотность
    def __init__(self, density):
        self.density = round(density, 3)

    # Вывод данных фигуры в консоль
    def Print(self):
        pass

    # Вывод данных фигуры в файл
    def Write(self, ostream):
        pass

    # Вычисление периметра фигуры
    def Perimeter(self):
        pass
