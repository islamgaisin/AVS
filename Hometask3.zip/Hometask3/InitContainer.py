from extender import *
import random


# Заполняем контейнер, считывая данные из файла
def InitContainerWithFile(container, ifile):
    figNum = 0
    for line in ifile:
        info = line.split()
        if info[0] == "1":
            shape = Ball(int(info[1]), float(info[2]))
        elif info[0] == "2":
            shape = Parallelepiped(int(info[1]), int(info[2]), int(info[3]), float(info[4]))
        elif info[0] == "3":
            shape = Tetrahedron(int(info[1]), float(info[2]))
        else:
            return -1
        figNum += 1
        container.store.append(shape)
    return figNum


# Заполняем контейнер, генерируя данные с помощью рандома
def InitContainerWithRandom(container, number):
    for i in range(number):
        k = random.randint(1, 4)
        if k == 1:
            shape = Ball(random.randint(1, 25), random.randint(200, 1000) + random.random())
        elif k == 2:
            shape = Parallelepiped(random.randint(1, 25), random.randint(1, 25),
                                   random.randint(1, 25), random.randint(200, 1000) + random.random())
        else:
            shape = Tetrahedron(random.randint(1, 25), random.randint(200, 1000) + random.random())
        container.store.append(shape)