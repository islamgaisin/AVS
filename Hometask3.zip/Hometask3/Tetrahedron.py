from shape import *


class Tetrahedron(Shape):
    # Конструктор, устанавливаем длину ребра тетраэдра
    def __init__(self, a, density):
        Shape.__init__(self, density)
        self.a = a

    # Выводим данные тетраэдра в консоль
    def Print(self):
        print("Tetrahedron: a = ", self.a, ", density = ", self.density, ", Volume = ", self.Volume())
        pass

    # Выводим данные тетраэдра в файл
    def Write(self, ostream):
        ostream.write("Tetrahedron: a = {}, density = {}, "
                      "Volume = {}\n".format(self.a, self.density, self.Volume()))
        pass

    # Вычисляем объем тетраэдра
    def Volume(self):
        return round(self.a ** 3 * 2 ** 0.5 / 12, 3)
        pass
