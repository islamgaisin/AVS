from shape import *
from Ball import *
from Parallelepiped import *
from Tetrahedron import *

from container import *
from InitContainer import *
