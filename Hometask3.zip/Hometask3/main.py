import sys
import string
import time

from extender import *

if __name__ == '__main__':
    start = time.time()
    # Проверка на корректность введенных данных
    if len(sys.argv) == 5:
        if sys.argv[1] == "-f":
            inputFileName = sys.argv[2]
            outputFileName = sys.argv[3]
            outputSortedName = sys.argv[4]
        elif sys.argv[1] == "-n":
            number = int(sys.argv[2])
            outputFileName = sys.argv[3]
            outputSortedName = sys.argv[4]
    else:
        print("Incorrect command line!\n"
              "    Waited:\n"
              "python main.py -f inputFileName outputFileName outputSortedFileName\n"
              "    Or:\n"
              "python main.py -n number outputFileName outputSortedFileName\n")
        exit()

    print('==> Start')
    container = Container()
    # Заполняем контейнер фигурами
    if sys.argv[1] == "-f":
        ifile = open(inputFileName, 'r')
        figNum = InitContainerWithFile(container, ifile)
        if figNum == -1:
            print("Invalid shape arguments")
            exit()
        container.Print()
        ifile.close()
    else:
        InitContainerWithRandom(container, number)

    # Записываем данные контейнера в файл
    ofile = open(outputFileName, 'w')
    ofile.write("Container stores {} shapes:\n".format(len(container.store)))
    container.Write(ofile)
    ofile.close()

    # Сортируем контейнер
    container.SortWithBinaryInsertion()

    # Записываем данные отсортированного контейнера в файл
    osfile = open(outputSortedName, 'w')
    osfile.write("Sorted container stores {} shapes:\n".format(len(container.store)))
    container.Write(osfile)
    osfile.close()

    print('==> Finish')
    end = time.time()
    print("Run-time = ", end - start, " sec")
