from shape import *


# Класс Параллелепипед
class Parallelepiped(Shape):
    # Конструктор, устанавливаем длину, ширину и высоту
    def __init__(self, x, y, z, density):
        Shape.__init__(self, density)
        self.x = x
        self.y = y
        self.z = z

    # Выводим данные параллелепипеда в консоль
    def Print(self):
        print("Parallelepiped: x = ", self.x, ", y = ", self.y, ", z = ", self.z,
              ", density = ", self.density, ", Volume = ", self.Volume())
        pass

    # Выводим данные параллелепипеда в файл
    def Write(self, ostream):
        ostream.write("Parallelepiped: x = {}, y = {}, z = {}, density = {}, "
                      "Volume = {}\n".format(self.x, self.y, self.z, self.density, self.Volume()))
        pass

    # Вычисляем объем параллелепипеда
    def Volume(self):
        return self.x * self.y * self.z
        pass
