from shape import *


# Класс Шар
class Ball(Shape):
    # Конструктор, устанавливаем радиус
    def __init__(self, radius, density):
        Shape.__init__(self, density)
        self.radius = radius

    # Выводим данные шара в консоль
    def Print(self):
        print("Ball: radius = ", self.radius, " density = ", self.density, ", Volume = ", self.Volume())
        pass

    # Выводим данные шара в файл
    def Write(self, ostream):
        ostream.write("Ball: radius = {}, density = {}, Volume = {}\n".format(self.radius, self.density, self.Volume()))
        pass

    # Вычисляем объем шара
    def Volume(self):
        return round(4.0 / 3 * 3.141592 * self.radius ** 3, 3)
        pass
