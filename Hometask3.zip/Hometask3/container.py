# Класс Контейнер
class Container:
    # Конструктор, инициализируем список фигур
    def __init__(self):
        self.store = []

    # Вывод содержимого в консоль
    def Print(self):
        print("Container is store", len(self.store), "shapes:")
        for shape in self.store:
            shape.Print()
        pass

    # Вывод содержимого в файл
    def Write(self, ostream):
        for shape in self.store:
            shape.Write(ostream)
        pass

    # Сортировка списка с помощью Binary Insertion сортировки
    def SortWithBinaryInsertion(self):
        for i in range(len(self.store)):
            currentShape = self.store[i]
            left = 0
            right = i
            while left < right:
                middle = left + (right - left) // 2
                if currentShape.Volume() < self.store[middle].Volume():
                    right = middle
                else:
                    left = middle + 1
            for j in range(i, left, -1):
                self.store[j] = self.store[j - 1]
            self.store[left] = currentShape
