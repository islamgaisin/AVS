#include <iostream>
#include <thread>
#include <cstdlib>
#include <chrono>

// Функция, моделирующая военные действия Анчуарии
// field - поле Тарантерии, weapon - оружие, которое есть у Анчуарии, width и length -
// размеры поля Тарантерии, value - флаг для разграничения действия потоков,
// number_of_weapon - кол-во оружия Анчуарии, number_of_objects - текущее кол-во
// неуничтоженных объектов Тарантерии, objects_cost - стоимость объектов Тарантерии,
// is_end - признак окончания войны.
void anchuariaAttacksTheField(int **field, int *weapon, int width, int length, bool &value,
                    int number_of_weapon, int number_of_objects, int objects_cost, bool &is_end) {
    // Стоимость потраченных снарядов.
    int spend_weapon_cost = 0, weapon_index, w, l;
    while (!is_end && number_of_objects > 0 && spend_weapon_cost <= objects_cost) {
        if (value) {
            weapon_index = rand() % number_of_weapon;
            w = rand() % width;
            l = rand() % length;
            if (field[w][l] != 0) {
                spend_weapon_cost += weapon[weapon_index];
                std::cout << "Анчуария атаковала ячейку [" << w + 1 << ", " << l + 1 << "] снарядом стоимостью "
                          << weapon[weapon_index] << ", осталось объектов: " << number_of_objects
                          << ", потраченная стоимость снарядов: " << spend_weapon_cost << "\n";
                weapon[weapon_index] = 0;
            } else {
                std::cout << "Тарантерия атаковала ячейку без объекта снарядом стоимостью "
                          << weapon[weapon_index] << ", потраченная стоимость снарядов "
                          << spend_weapon_cost << "\n";
                spend_weapon_cost += weapon[weapon_index];
                weapon[weapon_index] = 0;
            }
            if (number_of_objects == 0 || spend_weapon_cost > objects_cost) {
                is_end = true;
            }
            value = !value;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
    if (number_of_objects == 0) {
        std::cout << "Анчуария прекращает войну. Все объекты уничтожены." << "\n";
    } else if (spend_weapon_cost > objects_cost) {
        std::cout << "Анчуария прекращает войну. Стоимость потраченных снарядов превысила стоимость объектов." << "\n";
    } else {
        std::cout << "Анчуария еще может продолжать войну." << "\n";
    }
}

// Функция, моделирующая военные действия Тарантерии
// field - поле Анчуарии, weapon - оружие, которое есть у Тарантерии, width и length -
// размеры поля Анчуарии, value - флаг для разграничения действия потоков,
// number_of_weapon - кол-во оружия Тарантерии, number_of_objects - текущее кол-во
// неуничтоженных объектов Анчуарии, objects_cost - стоимость объектов Анчуарии,
// is_end - признак окончания войны.
void taranteriaAttacksTheField(int **field, int *weapon, int width, int length, bool &value,
                              int number_of_weapon, int number_of_objects, int objects_cost, bool &is_end) {
    // Стоимость потраченных снарядов.
    int spend_weapon_cost = 0, weapon_index, w, l;
    while (!is_end && number_of_objects > 0 && spend_weapon_cost <= objects_cost) {
        if (!value) {
            weapon_index = rand() % number_of_weapon;
            w = rand() % width;
            l = rand() % length;
            if (field[w][l] != 0) {
                field[w][l] = 0;
                --number_of_objects;
                spend_weapon_cost += weapon[weapon_index];
                std::cout << "Тарантерия атаковала ячейку [" << w + 1 << ", " << l + 1 << "] снарядом стоимостью "
                          << weapon[weapon_index] << ", осталось объектов: " << number_of_objects
                          << ", потраченная стоимость снарядов: " << spend_weapon_cost << "\n";
                weapon[weapon_index] = 0;
            } else {
                std::cout << "Тарантерия атаковала ячейку без объекта снарядом стоимостью "
                          << weapon[weapon_index] << ", потраченная стоимость снарядов "
                          << spend_weapon_cost << "\n";
                spend_weapon_cost += weapon[weapon_index];
                weapon[weapon_index] = 0;
            }
            if (number_of_objects == 0 || spend_weapon_cost > objects_cost) {
                is_end = true;
            }
            value = !value;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
    if (number_of_objects == 0) {
        std::cout << "Тарантерия прекращает войну. Все объекты уничтожены." << "\n";
    } else if (spend_weapon_cost > objects_cost) {
        std::cout << "Тарантерия прекращает войну. Стоимость потраченных снарядов превысила стоимость объектов." << "\n";
    } else {
        std::cout << "Тарантерия еще может продолжать войну." << "\n";
    }
}

void errMessage1() {
    std::cout << "Некорректные введенные данные!\n"
                 "Ожидалось:\n"
                 "   command anch_width anch_length taran_width taran_length\n"
                 "Все числа должны быть целыми от 1 до 10 включительно.\n";
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        errMessage1();
        return 1;
    }
    srand(static_cast<unsigned int>(time(0)));

    // Создание и инициализация параметров Анчуарии
    int anch_width, anch_length;
    try {
        anch_width = std::stoi(argv[1]);//rand() % 10 + 1;
        anch_length = std::stoi(argv[2]);//rand() % 10 + 1;
        if (anch_width < 1 || anch_width > 10 || anch_length < 1 || anch_length > 10) {
            throw std::invalid_argument("");
        }
    } catch (std::invalid_argument ex) {
        errMessage1();
        return 0;
    }
    int anch_objects_count = 0;
    int anch_objects_cost = 0;
    int **anch_field = new int *[anch_width];
    for (int i = 0; i < anch_width; ++i) {
        anch_field[i] = new int[anch_length];
        for (int j = 0; j < anch_length; ++j) {
            anch_field[i][j] = rand() % 21;
            if (anch_field[i][j] != 0) {
                ++anch_objects_count;
                anch_objects_cost += anch_field[i][j];
            }
        }
    }
    int anch_number_of_weapon = rand() % 500 + 1;
    int *anch_weapon = new int[anch_number_of_weapon];
    for (int i = 0; i < anch_number_of_weapon; ++i) {
        anch_weapon[i] = rand() % 10 + 1;
    }
    // Вывод параметров Анчуарии
    std::cout << "Поле Анчуарии:" << "\n";
    for (int i = 0; i < anch_width; ++i) {
        for (int j = 0; j < anch_length; ++j) {
            std::cout << anch_field[i][j] << " ";
        }
        std::cout << "\n";
    }
    std::cout << "Стоимость поля Анчуарии: " << anch_objects_cost
              << ", количество объектов: " << anch_objects_count << "\n";
    std::cout << "Стоимость снарядов Анчуарии: ";
    for (int i = 0; i < anch_number_of_weapon; ++i) {
        std::cout << anch_weapon[i] << " ";
    }
    std::cout << "\n\n";

    // Создание и инициализация параметров Тарантерии
    int taran_width, taran_length;
    try {
        taran_width = std::stoi(argv[3]);//rand() % 10 + 1;
        taran_length = std::stoi(argv[4]);//rand() % 10 + 1;
        if (taran_width < 1 || taran_width > 10 || taran_length < 1 || taran_length > 10) {
            throw std::invalid_argument("");
        }
    } catch (std::invalid_argument ex) {
        errMessage1();
        return 0;
    }
    int taran_objects_count = 0;
    int taran_objects_cost = 0;
    int **taran_field = new int *[taran_width];
    for (int i = 0; i < taran_width; ++i) {
        taran_field[i] = new int[taran_length];
        for (int j = 0; j < taran_length; ++j) {
            taran_field[i][j] = rand() % 21;
            if (taran_field[i][j] != 0) {
                ++taran_objects_count;
                taran_objects_cost += taran_field[i][j];
            }
        }
    }
    int taran_number_of_weapon = rand() % 500 + 1;
    int *taran_weapon = new int[taran_number_of_weapon];
    for (int i = 0; i < taran_number_of_weapon; ++i) {
        taran_weapon[i] = rand() % 10 + 1;
    }
    // Вывод параметров Тарантерии
    std::cout << "Поле Тарантерии:" << "\n";
    for (int i = 0; i < taran_width; ++i) {
        for (int j = 0; j < taran_length; ++j) {
            std::cout << taran_field[i][j] << " ";
        }
        std::cout << "\n";
    }
    std::cout << "Стоимость поля Тарантерии: " << taran_objects_cost
              << ", количество объектов: " << taran_objects_count << "\n";
    std::cout << "Стоимость снарядов Тарантерии: ";
    for (int i = 0; i < taran_number_of_weapon; ++i) {
        std::cout << taran_weapon[i] << " ";
    }
    std::cout << "\n\n";

    // Начало войны
    std::cout << "Война началась." << "\n";
    bool value = true, is_end = false;
    std::thread anch_thread (anchuariaAttacksTheField, taran_field, anch_weapon,
                             taran_width, taran_length, std::ref(value),
                             anch_number_of_weapon, taran_objects_count, taran_objects_cost, std::ref(is_end));
    std::thread taran_thread (taranteriaAttacksTheField, anch_field, taran_weapon,
                              anch_width, anch_length, std::ref(value),
                              taran_number_of_weapon, anch_objects_count, anch_objects_cost, std::ref(is_end));
    anch_thread.join();
    taran_thread.join();
    std::cout << "Война закончилась." << "\n";

    // Освобождение занятой памяти
    for (int i = 0; i < anch_width; ++i) {
        delete[] anch_field[i];
        anch_field[i] = nullptr;
    }
    delete[] anch_field;
    anch_field = nullptr;
    delete[] anch_weapon;
    anch_weapon = nullptr;

    for (int i = 0; i < taran_width; ++i) {
        delete[] taran_field[i];
        taran_field[i] = nullptr;
    }
    delete[] taran_field;
    taran_field = nullptr;
    delete[] taran_weapon;
    taran_weapon = nullptr;
    return 0;
}
